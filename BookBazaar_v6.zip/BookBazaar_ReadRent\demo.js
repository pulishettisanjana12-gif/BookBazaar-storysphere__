// demo.js — Demo data seeder for presentation purposes
// Populates localStorage with a realistic demo session:
//   - A signed-in demo user
//   - 3 active rentals (varying due dates: one due soon, one normal, one new)
//   - 2 cart items (one rent, one buy)
//   - 2 student sell listings
// Call seedDemo() to load, clearDemo() to wipe.

import { createLogger } from "./logger.js";

const log = createLogger("demo");

const NOW  = Date.now();
const DAY  = 86400000;

const DEMO_USER = {
  id:    "u_demo_001",
  name:  "Priya Sharma",
  email: "priya@bookbazaar.demo",
  _pw:   btoa("bb:demo1234"),
};

const DEMO_TOKEN = (() => {
  const b64 = obj => btoa(JSON.stringify(obj)).replace(/=/g,"").replace(/\+/g,"-").replace(/\//g,"_");
  const header  = b64({ alg: "DEMO", typ: "JWT" });
  const payload = b64({ sub: DEMO_USER.id, name: DEMO_USER.name, email: DEMO_USER.email, iat: NOW, exp: NOW + DAY });
  const sig     = payload.split("").reverse().join("").slice(0, 16);
  return `${header}.${payload}.${sig}`;
})();

const DEMO_RENTALS = [
  // Due in 4 days — warning state
  { bookId: 1,  mode: "rent", price: 190, deposit: 95,  duration: 60,  start: NOW - 56 * DAY, due: NOW + 4  * DAY },
  // Due in 38 days — normal state
  { bookId: 12, mode: "rent", price: 490, deposit: 245, duration: 120, start: NOW - 82 * DAY, due: NOW + 38 * DAY },
  // Due in 97 days — brand new rental
  { bookId: 3,  mode: "rent", price: 250, deposit: 125, duration: 120, start: NOW - 23 * DAY, due: NOW + 97 * DAY },
];

const DEMO_CART = [
  // Rent item
  { bookId: 9,  mode: "rent",  price: 340, deposit: 170, duration: 120 },
  // Buy secondhand item
  { bookId: 5,  mode: "used",  price: 590, deposit: 0,   duration: 0   },
];

const DEMO_LISTINGS = [
  {
    id: 1700000001000,
    isbn: "9780262046305",
    title: "Introduction to Algorithms",
    condition: "Good with Notes",
    price: 950,
    notes: "Thorough highlights in chapters 1–8. Very helpful for exams.",
  },
  {
    id: 1700000002000,
    isbn: "9780133943030",
    title: "Software Engineering",
    condition: "Like New",
    price: 750,
    notes: "Barely used. No marks. Selling because switched electives.",
  },
];

/**
 * Seeds all demo data into localStorage and reloads the page.
 * Skips if demo data is already present (idempotent).
 */
export function seedDemo() {
  try {
    // Register demo user
    const existing = JSON.parse(localStorage.getItem("bb_users") || "[]");
    if (!existing.find(u => u.email === DEMO_USER.email)) {
      existing.push(DEMO_USER);
      localStorage.setItem("bb_users", JSON.stringify(existing));
    }
    // Set session token (signs in as demo user)
    localStorage.setItem("bb_session", DEMO_TOKEN);
    // Set app slices
    localStorage.setItem("bb_rentals",  JSON.stringify(DEMO_RENTALS));
    localStorage.setItem("bb_cart",     JSON.stringify(DEMO_CART));
    localStorage.setItem("bb_listings", JSON.stringify(DEMO_LISTINGS));

    log.info("demo seeded — reloading");
    window.location.reload();
  } catch (e) {
    log.error("seedDemo failed", e.message);
    alert("Could not seed demo data: " + e.message);
  }
}

/**
 * Clears all demo data from localStorage and reloads the page.
 */
export function clearDemo() {
  try {
    ["bb_session", "bb_rentals", "bb_cart", "bb_listings", "bb_users"].forEach(k =>
      localStorage.removeItem(k)
    );
    log.info("demo cleared — reloading");
    window.location.reload();
  } catch (e) {
    log.error("clearDemo failed", e.message);
  }
}
