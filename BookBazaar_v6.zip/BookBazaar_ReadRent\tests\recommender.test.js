// tests/recommender.test.js — Unit tests for content-based recommendation engine

// Mock sessionStorage for logger
global.sessionStorage = { getItem: () => null, setItem: () => {}, removeItem: () => {} };

import { getRecommendations } from "../recommender.js";
import { books } from "../data.js";

describe("getRecommendations — cold start (no history)", () => {
  test("returns topN items when no rental history", () => {
    const recs = getRecommendations([], 4);
    expect(recs.length).toBe(4);
  });
  test("cold-start items are sorted by buyback descending", () => {
    const recs = getRecommendations([], 5);
    for (let i = 1; i < recs.length; i++) {
      expect(recs[i - 1].book.buyback).toBeGreaterThanOrEqual(recs[i].book.buyback);
    }
  });
  test("cold-start reason is 'Popular pick'", () => {
    const recs = getRecommendations([], 2);
    expect(recs.every(r => r.reason === "Popular pick")).toBe(true);
  });
  test("respects topN parameter", () => {
    expect(getRecommendations([], 2).length).toBe(2);
    expect(getRecommendations([], 6).length).toBe(6);
  });
});

describe("getRecommendations — with rental history", () => {
  // User rented 3 CS books
  const csHistory = [
    { bookId: 2 },  // OS Concepts — Computer Science
    { bookId: 3 },  // Core Java — Computer Science
    { bookId: 4 },  // Data Structures — Computer Science
  ];

  test("returns topN recommendations", () => {
    expect(getRecommendations(csHistory, 4).length).toBe(4);
  });
  test("does not recommend already-rented books", () => {
    const rentedIds = new Set(csHistory.map(r => r.bookId));
    const recs = getRecommendations(csHistory, 4);
    expect(recs.every(r => !rentedIds.has(r.book.id))).toBe(true);
  });
  test("favours same branch as rental history", () => {
    const recs = getRecommendations(csHistory, 4);
    // At least 2 of top 4 should be CS since that's the dominant branch
    const csCount = recs.filter(r => r.book.branch === "Computer Science").length;
    expect(csCount).toBeGreaterThanOrEqual(2);
  });
  test("scores are in descending order", () => {
    const recs = getRecommendations(csHistory, 6);
    for (let i = 1; i < recs.length; i++) {
      expect(recs[i - 1].score).toBeGreaterThanOrEqual(recs[i].score);
    }
  });
  test("reason mentions the dominant branch", () => {
    const recs = getRecommendations(csHistory, 4);
    const topRec = recs[0];
    expect(topRec.reason).toContain("Computer Science");
  });
  test("each result has book, score, reason", () => {
    getRecommendations(csHistory, 3).forEach(r => {
      expect(r.book).toBeTruthy();
      expect(typeof r.score).toBe("number");
      expect(typeof r.reason).toBe("string");
    });
  });
});
