// tests/auth.test.js
// Unit tests for the simulated JWT auth layer

// Mock localStorage for Node environment
const store = {};
global.localStorage = {
  getItem:    key => store[key] ?? null,
  setItem:    (key, val) => { store[key] = val; },
  removeItem: key => { delete store[key]; },
};
global.btoa = s => Buffer.from(s).toString("base64");
global.atob = s => Buffer.from(s, "base64").toString();

import { signUp, signIn, signOut, currentUser, isAuthenticated } from "../auth.js";

// Clear users + session between tests
beforeEach(() => { Object.keys(store).forEach(k => delete store[k]); });

describe("signUp", () => {
  test("valid registration returns ok", () => {
    const { ok, user } = signUp({ name: "Priya Sharma", email: "priya@college.edu", password: "secure1" });
    expect(ok).toBe(true);
    expect(user.email).toBe("priya@college.edu");
  });
  test("missing name fails", () => {
    expect(signUp({ name: "", email: "a@b.com", password: "pass123" }).ok).toBe(false);
  });
  test("invalid email fails", () => {
    expect(signUp({ name: "Test", email: "notanemail", password: "pass123" }).ok).toBe(false);
  });
  test("short password fails", () => {
    expect(signUp({ name: "Test", email: "t@b.com", password: "123" }).ok).toBe(false);
  });
  test("duplicate email fails", () => {
    signUp({ name: "A", email: "dup@b.com", password: "pass123" });
    const { ok, error } = signUp({ name: "B", email: "dup@b.com", password: "pass456" });
    expect(ok).toBe(false);
    expect(error).toMatch(/already exists/i);
  });
  test("email matching is case-insensitive", () => {
    signUp({ name: "A", email: "Upper@B.com", password: "pass123" });
    const { ok } = signUp({ name: "B", email: "upper@b.com", password: "pass456" });
    expect(ok).toBe(false);
  });
});

describe("signIn", () => {
  beforeEach(() => { signUp({ name: "Ravi Kumar", email: "ravi@uni.edu", password: "mypassword" }); });

  test("correct credentials return token", () => {
    const { ok, token } = signIn({ email: "ravi@uni.edu", password: "mypassword" });
    expect(ok).toBe(true);
    expect(token).toBeTruthy();
    expect(token.split(".").length).toBe(3);
  });
  test("wrong password fails", () => {
    const { ok, error } = signIn({ email: "ravi@uni.edu", password: "wrongpass" });
    expect(ok).toBe(false);
    expect(error).toBeTruthy();
  });
  test("unknown email fails", () => {
    expect(signIn({ email: "ghost@uni.edu", password: "pass" }).ok).toBe(false);
  });
  test("missing fields fails", () => {
    expect(signIn({ email: "", password: "" }).ok).toBe(false);
  });
});

describe("currentUser / isAuthenticated / signOut", () => {
  beforeEach(() => {
    signUp({ name: "Meera", email: "meera@uni.edu", password: "pass123" });
    signIn({ email: "meera@uni.edu", password: "pass123" });
  });

  test("currentUser returns user after sign-in", () => {
    const user = currentUser();
    expect(user).not.toBeNull();
    expect(user.email).toBe("meera@uni.edu");
    expect(user.name).toBe("Meera");
  });
  test("isAuthenticated is true after sign-in", () => {
    expect(isAuthenticated()).toBe(true);
  });
  test("signOut clears session", () => {
    signOut();
    expect(currentUser()).toBeNull();
    expect(isAuthenticated()).toBe(false);
  });
  test("currentUser returns null with no session", () => {
    Object.keys(store).forEach(k => delete store[k]);
    expect(currentUser()).toBeNull();
  });
});
