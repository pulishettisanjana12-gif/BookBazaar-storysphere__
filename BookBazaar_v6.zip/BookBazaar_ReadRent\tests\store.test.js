// tests/store.test.js
// Unit tests for the Observer-pattern store

// Mock localStorage
const storage = {};
global.localStorage = {
  getItem:    key => storage[key] ?? null,
  setItem:    (key, val) => { storage[key] = val; },
  removeItem: key => { delete storage[key]; },
};

import { initSlice, getSlice, setSlice, updateSlice, subscribe } from "../store.js";

beforeEach(() => { Object.keys(storage).forEach(k => delete storage[k]); });

describe("initSlice / getSlice", () => {
  test("initialises with fallback when nothing in storage", () => {
    initSlice("test_items", []);
    expect(getSlice("test_items")).toEqual([]);
  });
  test("reads existing value from localStorage", () => {
    storage["test_num"] = JSON.stringify(42);
    initSlice("test_num", 0);
    expect(getSlice("test_num")).toBe(42);
  });
});

describe("setSlice", () => {
  test("updates the value and persists it", () => {
    initSlice("ss_cart", []);
    setSlice("ss_cart", [{ id: 1 }]);
    expect(getSlice("ss_cart")).toEqual([{ id: 1 }]);
    expect(JSON.parse(storage["ss_cart"])).toEqual([{ id: 1 }]);
  });
});

describe("subscribe (Observer pattern)", () => {
  test("subscriber is called on setSlice", () => {
    initSlice("obs_a", 0);
    const calls = [];
    subscribe("obs_a", (newVal, oldVal) => calls.push({ newVal, oldVal }));
    setSlice("obs_a", 5);
    expect(calls.length).toBe(1);
    expect(calls[0].newVal).toBe(5);
    expect(calls[0].oldVal).toBe(0);
  });

  test("multiple subscribers all notified", () => {
    initSlice("obs_b", "x");
    const hits = [];
    subscribe("obs_b", () => hits.push("A"));
    subscribe("obs_b", () => hits.push("B"));
    setSlice("obs_b", "y");
    expect(hits).toEqual(["A", "B"]);
  });

  test("unsubscribe stops notifications", () => {
    initSlice("obs_c", 0);
    const hits = [];
    const unsub = subscribe("obs_c", v => hits.push(v));
    setSlice("obs_c", 1);
    unsub();
    setSlice("obs_c", 2);
    expect(hits).toEqual([1]); // only the first one
  });

  test("subscriber error does not break other subscribers", () => {
    initSlice("obs_d", 0);
    const hits = [];
    subscribe("obs_d", () => { throw new Error("boom"); });
    subscribe("obs_d", v => hits.push(v));
    expect(() => setSlice("obs_d", 99)).not.toThrow();
    expect(hits).toEqual([99]);
  });
});

describe("updateSlice", () => {
  test("applies updater function to current value", () => {
    initSlice("upd_arr", [1, 2]);
    updateSlice("upd_arr", arr => [...arr, 3]);
    expect(getSlice("upd_arr")).toEqual([1, 2, 3]);
  });
  test("triggers subscribers", () => {
    initSlice("upd_n", 10);
    const vals = [];
    subscribe("upd_n", v => vals.push(v));
    updateSlice("upd_n", n => n + 5);
    expect(vals).toEqual([15]);
  });
});
