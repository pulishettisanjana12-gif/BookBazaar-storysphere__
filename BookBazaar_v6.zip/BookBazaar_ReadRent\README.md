# BookBazaar — ReadRent Hack (Frontend Demo)

A responsive, frontend-only textbook rental and resale prototype built with semantic HTML5, CSS and vanilla JavaScript (ES6+), based on the uploaded **BookBazaar: ReadRent Hack** problem brief.

## Run the project
1. Extract `BookBazaar_ReadRent_Frontend.zip`.
2. Open the extracted folder.
3. Double-click `index.html` to launch in a modern browser.
4. No installation, backend, API key or build step is required.

## Features implemented
- Responsive academic textbook catalog with 25 sample titles.
- Search by title, author, ISBN and branch; branch and condition filters.
- Rent / buy secondhand / buy new comparison for every book.
- Rental duration calculator for 30, 60, 90 and 120 days.
- Rental deposit calculation (50% of rental fee) and estimated 80% deposit refund for verified good return, following the brief's suggested demo rule.
- Savings comparison against retail purchase price.
- Buyback price estimator for secondhand purchases.
- Four condition grades: Brand New, Like New, Good with Notes, Acceptable.
- Student resale form with ISBN-10 / ISBN-13 checksum validation.
- Active rental dashboard with due-date countdown and 7-day reminder indicator.
- Demo cart and checkout flow.
- LocalStorage persistence for cart, rentals and student listings.
- Mobile, tablet and desktop layouts; accessible labels and keyboard support.

## Important demo notes
- This is a **frontend-only prototype**. It does not connect to a server, real payment gateway, external ISBN service, or live inventory.
- Checkout, rental records and seller listings are demonstrations stored in the browser's LocalStorage on the device/browser used.
- Sample book records and prices are illustrative demo data. Verify actual titles, ISBNs, editions and prices before a live launch.
- The listing form collects book details and notes; it does not upload image files in this version.
- The return reminder is shown in the dashboard when 7 or fewer days remain; no email/SMS/push notification is sent.
- Security deposit policy in this demo follows the brief's suggested calculation: 50% deposit charged and 80% of that deposit estimated as refundable after a verified good-condition return.

## Files
- `index.html` — page structure and sections
- `styles.css` — visual design and responsive styling
- `app.js` — catalog data, filters, calculators, cart, ISBN checks, LocalStorage and dashboard logic

## Suggested demo walkthrough
1. Search for **Operating System Concepts**.
2. Open the book and select **Rent for semester**.
3. Keep 120 days selected: the sample retail price is ₹1,450 and the rental price is ₹380.
4. Show the deposit and savings calculation.
5. Add the rental to cart and complete the demo checkout.
6. Scroll to **Keep your rentals on track** to show the active rental and due date.
7. Open **Sell a book** and demonstrate ISBN validation.

## Submission
Upload the ZIP file to your LetzProject submission and include the README for setup and feature details. Add your own name, roll number and class details in the submission description if your portal requires them.
