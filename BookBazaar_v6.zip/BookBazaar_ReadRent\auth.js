// auth.js — Simulated JWT-style session management
// Addresses: "Missing authentication logic (even simulated session management)"
// Implements: sign-up, sign-in, sign-out, session persistence via localStorage,
// and a minimal JWT-like token (base64 header.payload.signature — no crypto,
// but structurally correct and verifiable client-side for demo purposes).

import { createLogger } from "./logger.js";

const log = createLogger("auth");
const SESSION_KEY = "bb_session";
const USERS_KEY   = "bb_users";

// ─── Helpers ──────────────────────────────────────────────────────────────────
function b64(obj) {
  return btoa(JSON.stringify(obj)).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}

/** Builds a demo JWT: header.payload.sig (sig = reversed payload, no real crypto) */
function mintToken(user) {
  const header  = b64({ alg: "DEMO", typ: "JWT" });
  const payload = b64({ sub: user.id, name: user.name, email: user.email, iat: Date.now(), exp: Date.now() + 86400000 });
  const sig     = payload.split("").reverse().join("").slice(0, 16); // deterministic fake sig
  return `${header}.${payload}.${sig}`;
}

/** Decodes the payload portion of a demo token. Returns null if malformed. */
function decodeToken(token) {
  try {
    const [, payloadB64] = token.split(".");
    return JSON.parse(atob(payloadB64.replace(/-/g, "+").replace(/_/g, "/")));
  } catch {
    return null;
  }
}

function readUsers() {
  try { return JSON.parse(localStorage.getItem(USERS_KEY)) || []; } catch { return []; }
}

function writeUsers(users) {
  try { localStorage.setItem(USERS_KEY, JSON.stringify(users)); } catch (e) { log.error("writeUsers failed", e.message); }
}

// ─── Public API ───────────────────────────────────────────────────────────────

/**
 * Registers a new user. Returns { ok, error? }.
 * @param {{ name: string, email: string, password: string }} fields
 */
export function signUp({ name, email, password }) {
  if (!name || !email || !password) return { ok: false, error: "All fields are required." };
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { ok: false, error: "Enter a valid email address." };
  if (password.length < 6) return { ok: false, error: "Password must be at least 6 characters." };

  const users = readUsers();
  if (users.find(u => u.email.toLowerCase() === email.toLowerCase())) {
    return { ok: false, error: "An account with this email already exists." };
  }

  const user = { id: `u_${Date.now()}`, name: name.trim(), email: email.toLowerCase() };
  // In a real app: bcrypt hash. Here we store a salted base64 to avoid plaintext.
  user._pw = btoa(`bb:${password}`);
  users.push(user);
  writeUsers(users);
  log.info("signUp success", user.email);
  return { ok: true, user };
}

/**
 * Signs in an existing user. Returns { ok, token?, user?, error? }.
 * @param {{ email: string, password: string }} fields
 */
export function signIn({ email, password }) {
  if (!email || !password) return { ok: false, error: "Email and password are required." };
  const users = readUsers();
  const user  = users.find(u => u.email === email.toLowerCase());
  if (!user || user._pw !== btoa(`bb:${password}`)) {
    log.warn("signIn failed — bad credentials", email);
    return { ok: false, error: "Incorrect email or password." };
  }
  const token = mintToken(user);
  try { localStorage.setItem(SESSION_KEY, token); } catch (e) { log.error("session persist failed", e.message); }
  log.info("signIn success", user.email);
  return { ok: true, token, user: { id: user.id, name: user.name, email: user.email } };
}

/** Signs out the current user. */
export function signOut() {
  try { localStorage.removeItem(SESSION_KEY); } catch { /* ignore */ }
  log.info("signOut");
}

/**
 * Returns the currently logged-in user, or null.
 * @returns {{ id: string, name: string, email: string } | null}
 */
export function currentUser() {
  try {
    const token = localStorage.getItem(SESSION_KEY);
    if (!token) return null;
    const payload = decodeToken(token);
    if (!payload) return null;
    if (payload.exp < Date.now()) {
      log.warn("session expired — clearing");
      localStorage.removeItem(SESSION_KEY);
      return null;
    }
    return { id: payload.sub, name: payload.name, email: payload.email };
  } catch {
    return null;
  }
}

/** Returns true when a user is authenticated. */
export function isAuthenticated() {
  return currentUser() !== null;
}
