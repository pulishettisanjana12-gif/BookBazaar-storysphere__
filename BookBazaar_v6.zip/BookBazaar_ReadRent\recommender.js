// recommender.js — Content-based book recommendation engine
// Innovation: scores catalogue books against a user's rental history using
// branch-affinity and condition-preference weights. No external library needed.
//
// Algorithm:
//   score(book) = branchWeight * branchMatch + conditionWeight * conditionMatch
//               + noveltyPenalty (demotes books already rented)
//
// Branch affinity: count how many times the user rented each branch,
//   normalise to [0,1], use as the branch match score.
// Condition preference: same approach over condition grades.
// Novelty: books already in rental history score 0 (no point re-renting).

import { books } from "./data.js";
import { createLogger } from "./logger.js";

const log = createLogger("recommender");

const BRANCH_WEIGHT    = 0.65;
const CONDITION_WEIGHT = 0.35;

/**
 * Builds frequency maps from rental history.
 * @param {Array<{ bookId: number }>} rentals
 * @returns {{ branchFreq: Map<string,number>, condFreq: Map<string,number>, rentedIds: Set<number> }}
 */
function buildProfile(rentals) {
  const branchFreq = new Map();
  const condFreq   = new Map();
  const rentedIds  = new Set();

  for (const r of rentals) {
    const book = books.find(b => b.id === r.bookId);
    if (!book) continue;
    rentedIds.add(book.id);
    branchFreq.set(book.branch, (branchFreq.get(book.branch) ?? 0) + 1);
    condFreq.set(book.condition, (condFreq.get(book.condition) ?? 0) + 1);
  }
  return { branchFreq, condFreq, rentedIds };
}

/**
 * Normalises a frequency map to [0,1] scores.
 * @param {Map<string,number>} freq
 * @returns {Map<string,number>}
 */
function normalise(freq) {
  const max = Math.max(...freq.values(), 1);
  return new Map([...freq.entries()].map(([k, v]) => [k, v / max]));
}

/**
 * Returns the top-N recommended books for a given rental history.
 * Falls back to highest-rated (by buyback ratio) books when history is empty.
 *
 * @param {Array<{ bookId: number }>} rentals   User's rental history slice
 * @param {number}                   topN       How many to return (default 4)
 * @returns {Array<{ book: object, score: number, reason: string }>}
 */
export function getRecommendations(rentals, topN = 4) {
  if (!rentals.length) {
    // Cold start: return top-N books by buyback ratio (proxy for popularity)
    log.debug("recommender cold start");
    return [...books]
      .sort((a, b) => b.buyback - a.buyback)
      .slice(0, topN)
      .map(book => ({ book, score: book.buyback, reason: "Popular pick" }));
  }

  const { branchFreq, condFreq, rentedIds } = buildProfile(rentals);
  const branchScore = normalise(branchFreq);
  const condScore   = normalise(condFreq);

  const scored = books
    .filter(b => !rentedIds.has(b.id))   // exclude already-rented
    .map(b => {
      const bs = branchScore.get(b.branch) ?? 0;
      const cs = condScore.get(b.condition) ?? 0;
      const score = BRANCH_WEIGHT * bs + CONDITION_WEIGHT * cs;
      const topBranch = [...branchFreq.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? "";
      const reason = bs > 0
        ? `Matches your ${topBranch} reading`
        : cs > 0 ? "Matches your preferred condition" : "You might like this";
      return { book: b, score, reason };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, topN);

  log.debug("recommendations computed", `top=${scored[0]?.book.title}`);
  return scored;
}
