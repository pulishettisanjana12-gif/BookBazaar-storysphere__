// pricing.js — Demand-based dynamic pricing engine
// Innovation: adjusts a book's displayed rent price up or down based on
// simulated demand derived from rental history frequency.
//
// Algorithm:
//   demandIndex(book) = rentalCount(book) / maxRentalCount across all books
//   surcharge        = BASE_RATE + demandIndex * MAX_SURCHARGE
//   dynamicPrice     = round(baseRent * surcharge)
//
// A book with zero rentals gets BASE_RATE (no change).
// The most-rented book gets BASE_RATE + MAX_SURCHARGE (capped at +35%).
// All prices are rounded to the nearest ₹10 for clean display.

import { books } from "./data.js";
import { createLogger } from "./logger.js";

const log = createLogger("pricing");

const BASE_RATE     = 1.0;   // no surcharge at zero demand
const MAX_SURCHARGE = 0.35;  // up to +35% for the most-rented book
const ROUND_TO      = 10;    // round to nearest ₹10

/**
 * Counts rentals per book from history.
 * @param {Array<{ bookId: number }>} rentals
 * @returns {Map<number, number>}  bookId → count
 */
function countRentals(rentals) {
  const freq = new Map();
  for (const r of rentals) {
    freq.set(r.bookId, (freq.get(r.bookId) ?? 0) + 1);
  }
  return freq;
}

/**
 * Returns a price map: bookId → { dynamicRent, surchargeLabel, demandLevel }
 * demandLevel: "HIGH" | "MEDIUM" | "NORMAL"
 *
 * @param {Array<{ bookId: number }>} rentals
 * @returns {Map<number, { dynamicRent: number, surchargeLabel: string, demandLevel: string }>}
 */
export function computeDynamicPrices(rentals) {
  const freq   = countRentals(rentals);
  const max    = Math.max(...freq.values(), 1);
  const result = new Map();

  for (const book of books) {
    const count       = freq.get(book.id) ?? 0;
    const demandIdx   = count / max;
    const multiplier  = BASE_RATE + demandIdx * MAX_SURCHARGE;
    const raw         = book.rent * multiplier;
    const dynamicRent = Math.round(raw / ROUND_TO) * ROUND_TO;

    const demandLevel  = demandIdx >= 0.75 ? "HIGH" : demandIdx >= 0.35 ? "MEDIUM" : "NORMAL";
    const surchargeLabel = demandLevel === "HIGH"
      ? "High demand · price adjusted"
      : demandLevel === "MEDIUM"
        ? "Moderate demand"
        : "";

    result.set(book.id, { dynamicRent, surchargeLabel, demandLevel });
  }

  log.debug("dynamic prices computed", `entries=${result.size}`);
  return result;
}

/**
 * Returns the dynamic rent for a single book. Falls back to base rent.
 * @param {number} bookId
 * @param {Map}    priceMap  Result of computeDynamicPrices()
 * @returns {number}
 */
export function getDynamicRent(bookId, priceMap) {
  return priceMap.get(bookId)?.dynamicRent ?? books.find(b => b.id === bookId)?.rent ?? 0;
}
