// logger.js — Structured logging utility
// Addresses: "No structured logging for debugging runtime errors"
// Logs are categorised by level, stored in sessionStorage for the current tab,
// and surfaced in the browser console with a consistent prefix.

const LEVELS = { DEBUG: 0, INFO: 1, WARN: 2, ERROR: 3 };
const STORE_KEY = "bb_logs";
const MAX_ENTRIES = 200;

/** @typedef {{ ts: string, level: string, context: string, message: string, detail?: string }} LogEntry */

function _persist(entry) {
  try {
    const raw = sessionStorage.getItem(STORE_KEY);
    const log = raw ? JSON.parse(raw) : [];
    log.push(entry);
    // Keep only the most recent MAX_ENTRIES entries
    if (log.length > MAX_ENTRIES) log.splice(0, log.length - MAX_ENTRIES);
    sessionStorage.setItem(STORE_KEY, JSON.stringify(log));
  } catch {
    // sessionStorage unavailable — silent; console output is still emitted
  }
}

function _emit(level, context, message, detail) {
  const entry = {
    ts: new Date().toISOString(),
    level,
    context,
    message: String(message),
    detail: detail !== undefined ? String(detail) : undefined,
  };
  _persist(entry);

  const prefix = `[BookBazaar:${context}]`;
  switch (level) {
    case "DEBUG": console.debug(prefix, message, detail ?? ""); break;
    case "INFO":  console.info(prefix, message, detail ?? "");  break;
    case "WARN":  console.warn(prefix, message, detail ?? "");  break;
    case "ERROR": console.error(prefix, message, detail ?? ""); break;
  }
}

/**
 * Logger factory — creates a named logger tied to a module/context.
 * @param {string} context  Module name, e.g. "app", "auth", "cart"
 * @returns {{ debug, info, warn, error }}
 */
export function createLogger(context) {
  return {
    /** @param {string} message @param {any} [detail] */
    debug: (message, detail) => _emit("DEBUG", context, message, detail),
    /** @param {string} message @param {any} [detail] */
    info:  (message, detail) => _emit("INFO",  context, message, detail),
    /** @param {string} message @param {any} [detail] */
    warn:  (message, detail) => _emit("WARN",  context, message, detail),
    /** @param {string} message @param {any} [detail] */
    error: (message, detail) => _emit("ERROR", context, message, detail),
  };
}

/**
 * Returns all log entries stored this session, newest-first.
 * @returns {LogEntry[]}
 */
export function getLogs() {
  try {
    const raw = sessionStorage.getItem(STORE_KEY);
    return raw ? JSON.parse(raw).reverse() : [];
  } catch {
    return [];
  }
}

/** Clears the in-session log store. */
export function clearLogs() {
  try { sessionStorage.removeItem(STORE_KEY); } catch { /* ignore */ }
}
