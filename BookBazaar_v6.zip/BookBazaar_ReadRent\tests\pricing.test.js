// tests/pricing.test.js — Unit tests for demand-based dynamic pricing engine

// Mock sessionStorage for logger
global.sessionStorage = { getItem: () => null, setItem: () => {}, removeItem: () => {} };

import { computeDynamicPrices, getDynamicRent } from "../pricing.js";
import { books } from "../data.js";

describe("computeDynamicPrices — no rental history", () => {
  test("returns a price entry for every book", () => {
    const map = computeDynamicPrices([]);
    expect(map.size).toBe(books.length);
  });
  test("with no rentals all prices equal base rent (demand index 0)", () => {
    const map = computeDynamicPrices([]);
    books.forEach(b => {
      // base multiplier = 1.0, rounded to nearest ₹10
      const expected = Math.round(b.rent / 10) * 10;
      expect(map.get(b.id).dynamicRent).toBe(expected);
    });
  });
  test("demandLevel is NORMAL when no rentals", () => {
    const map = computeDynamicPrices([]);
    books.forEach(b => expect(map.get(b.id).demandLevel).toBe("NORMAL"));
  });
});

describe("computeDynamicPrices — with rental history", () => {
  // Rent book id=1 many times to push it to HIGH demand
  const heavyHistory = Array.from({ length: 10 }, () => ({ bookId: 1 }));
  // Rent book id=2 a moderate number of times
  const mixedHistory = [
    ...Array.from({ length: 10 }, () => ({ bookId: 1 })),
    ...Array.from({ length: 4  }, () => ({ bookId: 2 })),
  ];

  test("most-rented book has HIGH demand level", () => {
    const map = computeDynamicPrices(heavyHistory);
    expect(map.get(1).demandLevel).toBe("HIGH");
  });
  test("most-rented book price is higher than base rent", () => {
    const map  = computeDynamicPrices(heavyHistory);
    const base = books.find(b => b.id === 1).rent;
    expect(map.get(1).dynamicRent).toBeGreaterThan(base);
  });
  test("max surcharge does not exceed 35% over base rent", () => {
    const map = computeDynamicPrices(heavyHistory);
    books.forEach(b => {
      const { dynamicRent } = map.get(b.id);
      expect(dynamicRent).toBeLessThanOrEqual(Math.ceil(b.rent * 1.35 / 10) * 10 + 10);
    });
  });
  test("book with zero rentals stays NORMAL when others are rented", () => {
    const map = computeDynamicPrices(heavyHistory);
    // book id=25 not rented at all
    expect(map.get(25).demandLevel).toBe("NORMAL");
  });
  test("moderate demand book is MEDIUM (between 35% and 75% of max)", () => {
    const map = computeDynamicPrices(mixedHistory);
    expect(map.get(2).demandLevel).toBe("MEDIUM");
  });
  test("HIGH demand entry has a non-empty surchargeLabel", () => {
    const map = computeDynamicPrices(heavyHistory);
    expect(map.get(1).surchargeLabel.length).toBeGreaterThan(0);
  });
  test("NORMAL entry has empty surchargeLabel", () => {
    const map = computeDynamicPrices([]);
    books.forEach(b => expect(map.get(b.id).surchargeLabel).toBe(""));
  });
});

describe("getDynamicRent", () => {
  test("returns dynamicRent from priceMap", () => {
    const map  = computeDynamicPrices([]);
    const book = books[0];
    expect(getDynamicRent(book.id, map)).toBe(map.get(book.id).dynamicRent);
  });
  test("falls back to base rent for unknown id", () => {
    const map = computeDynamicPrices([]);
    expect(getDynamicRent(999, map)).toBe(0);
  });
});
