// tests/validation.test.js
// Unit tests for ISBN validation and listing form validation
// Addresses evaluation recommendation: "Implement a suite of Jest tests"

import { validateISBN, validateListingForm, validateDuration } from "../validation.js";

// ─── ISBN-10 ──────────────────────────────────────────────────────────────────
describe("validateISBN — ISBN-10", () => {
  test("valid ISBN-10 with digit check", () => {
    expect(validateISBN("0471958697").valid).toBe(true);
  });
  test("valid ISBN-10 with X check digit", () => {
    expect(validateISBN("097522980X").valid).toBe(true);
  });
  test("invalid ISBN-10 wrong checksum", () => {
    expect(validateISBN("0471958698").valid).toBe(false);
  });
  test("X in non-final position is invalid", () => {
    expect(validateISBN("047X958697").valid).toBe(false);
  });
  test("strips hyphens before checking", () => {
    expect(validateISBN("0-47-1958697").valid).toBe(true);
  });
  test("empty string is invalid", () => {
    expect(validateISBN("").valid).toBe(false);
  });
});

// ─── ISBN-13 ──────────────────────────────────────────────────────────────────
describe("validateISBN — ISBN-13", () => {
  test("valid ISBN-13 from catalogue (Higher Engineering Mathematics)", () => {
    expect(validateISBN("9788174091956").valid).toBe(true);
  });
  test("valid ISBN-13 from catalogue (OS Concepts)", () => {
    expect(validateISBN("9781119800361").valid).toBe(true);
  });
  test("invalid ISBN-13 wrong last digit", () => {
    expect(validateISBN("9788174091951").valid).toBe(false);
  });
  test("ISBN-13 with letter fails", () => {
    expect(validateISBN("978817409195A").valid).toBe(false);
  });
  test("12-digit number is invalid", () => {
    expect(validateISBN("978817409195").valid).toBe(false);
  });
  test("strips spaces and hyphens", () => {
    expect(validateISBN("978-8174091956").valid).toBe(true);
  });
});

// ─── Wrong length ─────────────────────────────────────────────────────────────
describe("validateISBN — length edge cases", () => {
  test("11-digit input is invalid", () => {
    expect(validateISBN("97881740919").valid).toBe(false);
  });
  test("14-digit input is invalid", () => {
    expect(validateISBN("97881740919551").valid).toBe(false);
  });
  test("message mentions digit count", () => {
    const { message } = validateISBN("12345");
    expect(message).toMatch(/5/);
  });
});

// ─── Listing form validation ──────────────────────────────────────────────────
describe("validateListingForm", () => {
  const good = {
    isbn: "9788174091956",
    title: "Higher Engineering Mathematics",
    price: "500",
    condition: "Like New",
  };

  test("valid form passes", () => {
    expect(validateListingForm(good).valid).toBe(true);
  });

  test("negative price fails", () => {
    const { valid, errors } = validateListingForm({ ...good, price: "-50" });
    expect(valid).toBe(false);
    expect(errors.price).toBeTruthy();
  });

  test("zero price fails", () => {
    const { valid, errors } = validateListingForm({ ...good, price: "0" });
    expect(valid).toBe(false);
    expect(errors.price).toBeTruthy();
  });

  test("price above 10000 fails", () => {
    const { valid, errors } = validateListingForm({ ...good, price: "15000" });
    expect(valid).toBe(false);
    expect(errors.price).toBeTruthy();
  });

  test("decimal price fails", () => {
    const { valid, errors } = validateListingForm({ ...good, price: "499.50" });
    expect(valid).toBe(false);
    expect(errors.price).toBeTruthy();
  });

  test("empty title fails", () => {
    const { valid, errors } = validateListingForm({ ...good, title: "" });
    expect(valid).toBe(false);
    expect(errors.title).toBeTruthy();
  });

  test("two-character title fails", () => {
    const { valid, errors } = validateListingForm({ ...good, title: "Ab" });
    expect(valid).toBe(false);
    expect(errors.title).toBeTruthy();
  });

  test("title over 200 chars fails", () => {
    const { valid, errors } = validateListingForm({ ...good, title: "A".repeat(201) });
    expect(valid).toBe(false);
    expect(errors.title).toBeTruthy();
  });

  test("invalid ISBN fails", () => {
    // 0471958698 — one digit off from the valid 0471958697
    const { valid, errors } = validateListingForm({ ...good, isbn: "0471958698" });
    expect(valid).toBe(false);
    expect(errors.isbn).toBeTruthy();
  });

  test("unknown condition fails", () => {
    const { valid, errors } = validateListingForm({ ...good, condition: "Perfect" });
    expect(valid).toBe(false);
    expect(errors.condition).toBeTruthy();
  });

  test("multiple errors returned together", () => {
    const { valid, errors } = validateListingForm({ isbn: "bad", title: "", price: "-1", condition: "Perfect" });
    expect(valid).toBe(false);
    expect(Object.keys(errors).length).toBeGreaterThan(2);
  });
});

// ─── Duration validation ──────────────────────────────────────────────────────
describe("validateDuration", () => {
  test.each([30, 60, 90, 120])("%i days is valid", days => {
    expect(validateDuration(days).valid).toBe(true);
  });
  test("45 days is invalid", () => {
    expect(validateDuration(45).valid).toBe(false);
  });
  test("0 days is invalid", () => {
    expect(validateDuration(0).valid).toBe(false);
  });
  test("negative days is invalid", () => {
    expect(validateDuration(-30).valid).toBe(false);
  });
});
